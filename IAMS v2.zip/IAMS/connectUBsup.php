<?php

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Create connection
    $conn = mysqli_connect('localhost', 'root', '', 'db_iams');

    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
   
    // Check if coordinatorEmail and password are not empty
    if (!empty($_POST["ubSup_email"]) && !empty($_POST["ubSup_password"])) {
        // Password encoding
        $password = $_POST['ubSup_password'];
        $enc_password = password_hash($password, PASSWORD_DEFAULT);

        // Prepare SQL query
        $sql = "INSERT INTO ub_supervisor (ubSup_email, ubSup_password) VALUES (?, ?)";

        // Prepare statement
        $stmt = $conn->prepare($sql);

        // Bind parameters
        $stmt->bind_param("ss", $_POST["ubSup_email"], $enc_password);

        // Execute query
        if ($stmt->execute()) {
            echo "Registration successful";
        } else {
            echo "Error: " . $stmt->error;
        }

        // Close statement
        $stmt->close();
    } else {
        echo "Supervisor email and password are required";
    }

    // Close connection
    $conn->close();
}
?>
