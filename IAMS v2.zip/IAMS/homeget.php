<?php
  
    $conn = mysqli_connect('localhost', 'root', '', 'db_iams') or die(myslq_error());

   
?>
