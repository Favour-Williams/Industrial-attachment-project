<?php
// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Create connection
    $conn = mysqli_connect('localhost', 'root', '', 'db_iams');

    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Prepare SQL query for updating organization preferences
    $sql = "INSERT INTO organisation_preferences (orgId, typeOfWork) VALUES (?, ?) ON DUPLICATE KEY UPDATE typeOfWork = VALUES(typeOfWork)";

    // Prepare statement
    $stmt = $conn->prepare($sql);

    // Bind parameters
    $stmt->bind_param("ss", $_POST["orgId"], $_POST["typeOfWork"]);

    // Execute query
    if ($stmt->execute()) {
        echo "Preferences updated successfully";

        header("refresh:3;url=supervisorProfile.php");
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close statement
    $stmt->close();

    // Close connection
    $conn->close();
}
?>

