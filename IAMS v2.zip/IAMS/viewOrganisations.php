<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #ddd;
        }
    </style>
</head>
<body>
    <?php
        $conn = mysqli_connect('localhost', 'root', '', 'db_iams');

        // Check connection
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }
        
        function getStudentPreferences($conn) {
            $sql = "SELECT orgId, orgName FROM organisation";
            $stmt = $conn->prepare($sql);
            $stmt->execute();
            $result = $stmt->get_result();
            $studentInfo = $result->fetch_all(MYSQLI_ASSOC);
            return $studentInfo;
        }

        $studentInfo = getStudentPreferences($conn);
    ?>

    <table>
        <tr>
            <th>orgID</th>
            <th>orgName</th>
        </tr>
        <?php foreach ($studentInfo as $student): ?>
            <tr>
                <td><?php echo htmlspecialchars($student['orgId']);?></td>
                <td><?php echo htmlspecialchars($student['orgName']);?></td>
            </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
