<?php

$orgEmailerror = $supEmailerror = $phoneNumbererror = "";

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Create connection
    $conn = mysqli_connect('localhost', 'root', '', 'db_iams');

    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Check if the organization email already exists
    $org_email = $_POST["orgEmail"];
    $sql_check_org_email = "SELECT * FROM organisation WHERE orgEmail = ?";
    $stmt_check_org_email = $conn->prepare($sql_check_org_email);
    $stmt_check_org_email->bind_param("s", $org_email);
    $stmt_check_org_email->execute();
    $result_check_org_email = $stmt_check_org_email->get_result();

    // If the organization email already exists, set error message
    if ($result_check_org_email->num_rows > 0) {
        $orgEmailerror = "Error: Organization email already exists. Please choose a different one.";
    }

    // Check if the supervisor email already exists
    $sup_email = $_POST["supervisorEmail"];
    $sql_check_sup_email = "SELECT * FROM organisation WHERE supervisorEmail = ?";
    $stmt_check_sup_email = $conn->prepare($sql_check_sup_email);
    $stmt_check_sup_email->bind_param("s", $sup_email);
    $stmt_check_sup_email->execute();
    $result_check_sup_email = $stmt_check_sup_email->get_result();

    // If the supervisor email already exists, set error message
    if ($result_check_sup_email->num_rows > 0) {
        $supEmailerror = "Error: Supervisor email already exists. Please choose a different one.";
    }

    // Check if the phone number already exists
    $phone_number = $_POST["phoneNumber"];
    $sql_check_phone_number = "SELECT * FROM organisation WHERE phoneNumber = ?";
    $stmt_check_phone_number = $conn->prepare($sql_check_phone_number);
    $stmt_check_phone_number->bind_param("s", $phone_number);
    $stmt_check_phone_number->execute();
    $result_check_phone_number = $stmt_check_phone_number->get_result();

    // If the phone number already exists, set error message
    if ($result_check_phone_number->num_rows > 0) {
        $phoneNumbererror = "Error: Phone number already exists. Please choose a different one.";
    }

    // If there are no errors, proceed with registration
    if (empty($orgEmailerror) && empty($supEmailerror) && empty($phoneNumbererror)) {
        // Password encoding
        $password = $_POST['password'];
        $enc_password = password_hash($password, PASSWORD_DEFAULT);

        // Prepare SQL query
        $sql = "INSERT INTO organisation (orgName, supervisorName, supervisorEmail, orgEmail, address, orgId, password, phoneNumber, location) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        // Prepare statement
        $stmt = $conn->prepare($sql);

        // Bind parameters
        $stmt->bind_param("sssssssss", $_POST["orgName"], $_POST["supervisorName"], $_POST["supervisorEmail"], $_POST["orgEmail"], $_POST["address"], $_POST["orgId"], $enc_password, $_POST["phoneNumber"], $_POST["location"]);

        // Execute query
        if ($stmt->execute()) {
            echo "Registration successful";

            header("refresh:3;url=home.php");
        } else {
            echo "Error: " . $stmt->error;
        }

        // Close statement
        $stmt->close();
    }

    // Close connection
    $conn->close();
}

// If there's an error, include the HTML file for the form
if (!empty($orgEmailerror) || !empty($supEmailerror) || !empty($phoneNumbererror)) {
    include 'register-organization.html';
}
?>
