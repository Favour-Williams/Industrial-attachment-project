<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="student.css">
  <title>Coordinator Profile</title>
</head>
<style>
  .profile-img {
    position: relative; /* Ensure positioning context */
    margin-top: 10px; /* Adjust the margin to move the image down */
  }
  </style>
<body>

  <div class="center-box">
    <header>
      <nav class="navigation">
        <a href="#">Home</a>
        <a href="#">About</a>
        <a href="#">Services</a>
        <a href="#">Contacts</a>
      </nav>
    </header>
    <div class="container">
      <div class="profile">
        <div class="profile-img">
          <img src="pro.jpg" alt="Supervisor" id="profile">
        </div>
        <div class="profile-info">
          <h3>Welcome Supervisor</h3>
        </div>
      </div>
      <div class="flex-container">
        <div class="container2">
          <div class="container3">
            <div class="pairings">
              <p>Input Assessment Results:</p>
              <ol>
                <li><button class="sub"><a href="getMatch.php" class="sub">Input Assessment Results</a></button></li>
              </ol>
              
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script src="script.js"></script>
  <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
</body>
</html>
