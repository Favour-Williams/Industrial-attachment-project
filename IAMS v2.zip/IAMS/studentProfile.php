<?php
// Start session and retrieve student's email
session_start();
$student_email = $_SESSION['email'];

// Establish database connection
$conn = mysqli_connect('localhost', 'root', '', 'db_iams');
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Sanitize student's email to prevent SQL injection
$student_email = mysqli_real_escape_string($conn, $student_email);

// Query database to fetch student's information
$sel = "SELECT * FROM student WHERE email = '$student_email'";
$query = mysqli_query($conn, $sel);
if (!$query) {
    die("Query failed: " . mysqli_error($conn));
}

$resul = mysqli_fetch_assoc($query);
$student_id = $resul['studentID'];

// Function to retrieve matches for a specific student ID
function getStudentMatches($conn, $student_id) {
  $sql = "SELECT m.student_id, s.firstName AS student_name, m.organisation_id, o.orgName AS organisation_name 
          FROM matches AS m
          JOIN student AS s ON m.student_id = s.studentID
          JOIN organisation AS o ON m.organisation_id = o.orgId
          WHERE m.student_id = ?";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param("i", $student_id);
  $stmt->execute();
  $result = $stmt->get_result();
  $matches = $result->fetch_all(MYSQLI_ASSOC);
  return $matches;
}

// Check if the student has matches
$matches = getStudentMatches($conn, $student_id);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="student.css">
    <title>Student Profile</title>
</head>
<body>
<div class="center-box">
    <header>
        <nav class="navigation">
            <a href="#">Home</a>
            <a href="#">About</a>
            <a href="home.php">Logout</a>
            
        </nav>
    </header>
    <div class="container">
        <div class="profile">
            <div class="profile-img">
                <img src="sticon.webp" alt="Supervisor" id="profile">
            </div>
            <div class="profile-info">
                <h1>Welcome <?php echo $resul['firstName'] ?></h1>
                <p>Student</p>
                <p><strong>Name:</strong> <?php echo $resul['firstName'] ?></p>
                <p><strong>Email:</strong> <?php echo $resul['email'] ?></p>
                <p><strong>Student ID:</strong> <?php echo $resul['studentID'] ?></p>
                <!-- Display a message if matches are available -->
                <?php if (!empty($matches)) { ?>
                    <p style="color: green;">You have been matched! <a href="getMatch.php?student_id=<?php echo $student_id; ?>">Click here</a> to pick your match.</p>
                <?php } ?>
            </div>
        </div>
        <div class="flex-container">
            <div class="container2">
                <div class="container3">
                    <div class="pairings">
                        <p>Submit Logbooks:</p>
                        <ol>
                            <li><button class="sub"><a href="supervisor-form.html" class="sub">Submit Logbooks</a></button></li>
                        </ol>
                        <p>Submit Preferences:</p>
                        <ol>
                            <li><button class="sub"><a href="preferences.html" class="sub">Submit Preferences</a></button></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
