<?php
$conn = mysqli_connect('localhost', 'root', '', 'db_iams');

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Retrieve student ID from URL parameter
if (isset($_GET['student_id'])) {
    $student_id = $_GET['student_id'];

    // Fetch matches for the specified student ID
    $sql = "SELECT m.student_id, s.firstName AS student_name, m.organisation_id, o.orgName AS organisation_name 
            FROM matches AS m
            JOIN student AS s ON m.student_id = s.studentID
            JOIN organisation AS o ON m.organisation_id = o.orgId
            WHERE m.student_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $student_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $matches = $result->fetch_all(MYSQLI_ASSOC);
} else {
    // If no student ID is provided, display all matches
    $sql = "SELECT m.student_id, s.firstName AS student_name, m.organisation_id, o.orgName AS organisation_name 
            FROM matches AS m
            JOIN student AS s ON m.student_id = s.studentID
            JOIN organisation AS o ON m.organisation_id = o.orgId";
    $result = $conn->query($sql);
    $matches = $result->fetch_all(MYSQLI_ASSOC);
}

// Display matches with student first name and organisation name
echo "<h2>Matches</h2>";
echo "<table border='1'>";
echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
echo "<tr><th style='padding: 8px; background-color: #f2f2f2;'>Student ID</th>
      <th style='padding: 8px; background-color: #f2f2f2;'>Student Name</th>
      <th style='padding: 8px; background-color: #f2f2f2;'>Organisation ID</th>
      <th style='padding: 8px; background-color: #f2f2f2;'>Organisation Name</th></tr>";
foreach ($matches as $row) {
    echo "<tr>";
    echo "<td style='padding: 8px;'>" . htmlspecialchars($row['student_id']) . "</td>";
    echo "<td style='padding: 8px;'>" . htmlspecialchars($row['student_name']) . "</td>";
    echo "<td style='padding: 8px;'>" . htmlspecialchars($row['organisation_id']) . "</td>";
    echo "<td style='padding: 8px;'>" . htmlspecialchars($row['organisation_name']) . "</td>";
    echo "</tr>";
}
echo "</table>";

mysqli_close($conn);
?>
