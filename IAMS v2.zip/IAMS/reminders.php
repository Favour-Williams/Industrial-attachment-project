<?php
// Set connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_iams";

// Create a PDO connection
$pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);

// Get current date
$currentDate = new DateTime();

// Check if it's the last day of the week (Sunday)
if ($currentDate->format('N') == 7) {
    // If it's Sunday, set a flag in the database indicating that logbooks are due
    $sql = "UPDATE student SET logbooks_due = 1";
    $pdo->exec($sql);
}
?>
