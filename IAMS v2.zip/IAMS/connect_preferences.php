<?php
// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Create connection
    $conn = mysqli_connect('localhost', 'root', '', 'db_iams');

    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Prepare SQL query
    $sql = "INSERT INTO student_preferences (studentid, location, typeOfWork, bio) VALUES (?, ?, ?, ?)";

    // Prepare statement
    $stmt = $conn->prepare($sql);

    // Bind parameters
    $stmt->bind_param("ssss", $_POST["studentid"], $_POST["location"], $_POST["typeOfWork"], $_POST["bio"]);

    // Execute query
    if ($stmt->execute()) {
        echo "Preferences saved successfully";
        header("refresh:3;url=studentProfile.php");
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close statement
    $stmt->close();

    // Close connection
    $conn->close();
}
?>
