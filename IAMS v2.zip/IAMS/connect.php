<?php

$studentIderror = "";

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Create connection
    $conn = mysqli_connect('localhost', 'root', '', 'db_iams');

    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Check if the student ID already exists
    $student_id = $_POST["studentid"];
    $sql_check_id = "SELECT * FROM student WHERE studentid = ?";
    $stmt_check_id = $conn->prepare($sql_check_id);
    $stmt_check_id->bind_param("s", $student_id);
    $stmt_check_id->execute();
    $result_check_id = $stmt_check_id->get_result();

    // If the student ID already exists, set error message
    if ($result_check_id->num_rows > 0) {
        $studentIderror = "*Error: Student ID already exists. Please choose a different one.";
    } else {
        // Password encoding
        $password = $_POST['password'];
        $enc_password = password_hash($password, PASSWORD_DEFAULT);

        // Prepare SQL query
        $sql = "INSERT INTO student (firstName, lastName, email, studentid, age, password) VALUES (?, ?, ?, ?, ?, ?)";

        // Prepare statement
        $stmt = $conn->prepare($sql);

        // Bind parameters
        $stmt->bind_param("ssssis", $_POST["firstName"], $_POST["lastName"], $_POST["email"], $_POST["studentid"], $_POST["age"], $enc_password);

        // Execute query
        if ($stmt->execute()) {
            echo "Registration successful";

            header("refresh:3;url=home.php");
        } else {
            echo "Error: " . $stmt->error;
        }

        // Close statement
        $stmt->close();
    }

    // Close connection
    $conn->close();
}

// If there's an error, include the HTML file for the form
if (!empty($studentIderror)) {
    include 'register-attachment.html';
}
?>
