<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="supervisor.css">
  <title>Supervisor Profile</title>
</head>
<body>
  <?php
    // Assuming you have already started the session and stored the student's email
    session_start();
    $supervisor_email = $_SESSION['email'];

    // Assuming you have already established a database connection
    $conn = mysqli_connect('localhost', 'root', '', 'db_iams');

    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Sanitize the email to prevent SQL injection
    $supervisor_email = mysqli_real_escape_string($conn, $supervisor_email);

    $sel = "SELECT * FROM organisation WHERE supervisorEmail = '$supervisor_email'";
    $query = mysqli_query($conn, $sel);

    // Check if query was successful
    if (!$query) {
        die("Query failed: " . mysqli_error($conn));
    }

    // Fetch the supervisor's profile information
    $resul = mysqli_fetch_assoc($query);
    ?>
  <div class="center-box">
    <header>
      <nav class="navigation">
        <a href="#">Home</a>
        <a href="#">About</a>
        <a href="#">Services</a>
        <a href="home.php">Logout</a>
      </nav>
    </header>
    <div class="container">
      <div class="profile">
        <div class="profile-img">
          <img src="supic.avif" alt="Supervisor" id="profile">
        </div>
        <div class="profile-info">
        <h1>Welcome <?php echo $resul['supervisorName'] ?></h1>
          <p>Industrial Attachment Supervisor</p>
          <p><strong>Name:</strong> <?php echo $resul['supervisorName'] ?></p>
          <p><strong>Email:</strong> <?php echo $resul['supervisorEmail'] ?></p>
        </div>
      </div>
      <div class="flex-container">
        <div class="container2">
          
          <div class="container3">
            <div class="pairings">
              <p>Submit Student reports:</p>
              <ol>
                <li><button class="sub"><a href="supervisor-form.html" class="sub">Submit Report</a></button></li>
              </ol>
              <p>Submit Preferences:</p>
              <ol>
                <li><button class="sub"><a href="orgPreferences.html" class="sub">Submit Preferences</a></button></li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script src="script.js"></script>
  <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
</body>
</html>
