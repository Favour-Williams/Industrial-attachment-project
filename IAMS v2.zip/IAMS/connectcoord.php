<?php

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Create connection
    $conn = mysqli_connect('localhost', 'root', '', 'db_iams');

    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
   
    // Check if coordinatorEmail and password are not empty
    if (!empty($_POST["coordinatorEmail"]) && !empty($_POST["coordinatorPassword"])) {
        // Password encoding
        $password = $_POST['coordinatorPassword'];
        $enc_password = password_hash($password, PASSWORD_DEFAULT);

        // Prepare SQL query
        $sql = "INSERT INTO coordinator (coordinatorEmail, coordinatorPassword) VALUES (?, ?)";

        // Prepare statement
        $stmt = $conn->prepare($sql);

        // Bind parameters
        $stmt->bind_param("ss", $_POST["coordinatorEmail"], $enc_password);

        // Execute query
        if ($stmt->execute()) {
            echo "Registration successful";
        } else {
            echo "Error: " . $stmt->error;
        }

        // Close statement
        $stmt->close();
    } else {
        echo "Coordinator email and password are required";
    }

    // Close connection
    $conn->close();
}
?>
