<?php
// Start PHP session to maintain form data
session_start();

// Define variables to store form data
$date = $activities = $accomplishments = $challenges = $project_details = $tasks_completed = $hours_worked = '';

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $date = $_POST['date'];
    $activities = $_POST['activities'];
    $accomplishments = $_POST['accomplishments'];
    $challenges = $_POST['challenges'];
    $project_details = $_POST['project_details'];
    $tasks_completed = $_POST['tasks_completed'];
    $hours_worked = $_POST['hours_worked'];

    // Validate form data (you can add more validation as needed)
    // Here, we are just checking if required fields are not empty
    if (empty($date) || empty($activities) || empty($accomplishments) || empty($challenges) || empty($project_details) || empty($tasks_completed) || empty($hours_worked)) {
        $_SESSION['error'] = "All fields are required";
    } else {
        // Connect to the database (replace with your database details)
        $servername = "localhost";
        $username = "username";
        $password = "password";
        $dbname = "logbook";

        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Upload attachments
        $attachments = [];
        $uploadDir = 'uploads/';
        foreach ($_FILES['attachments']['name'] as $key => $name) {
            $tmp_name = $_FILES['attachments']['tmp_name'][$key];
            $uploadPath = $uploadDir . basename($name);
            if (move_uploaded_file($tmp_name, $uploadPath)) {
                $attachments[] = $uploadPath;
            }
        }

        // Insert data into database
        $sql = "INSERT INTO log_entries (date, activities, accomplishments, challenges, project_details, tasks_completed, hours_worked, attachments) VALUES ('$date', '$activities', '$accomplishments', '$challenges', '$project_details', '$tasks_completed', '$hours_worked', '" . implode(",", $attachments) . "')";

        if ($conn->query($sql) === TRUE) {
            $_SESSION['success'] = "New record created successfully";
        } else {
            $_SESSION['error'] = "Error: " . $sql . "<br>" . $conn->error;
        }

        $conn->close();
    }
}

// HTML starts here
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Weekly Log Book</title>
    <link rel="stylesheet" href="lb_styling.css">
</head>
<body>
    <div class="container">
        <h2>Weekly Log Book</h2>
        <?php
        // Display success or error message
        if (isset($_SESSION['success'])) {
            echo '<p class="success">' . $_SESSION['success'] . '</p>';
            unset($_SESSION['success']); // Clear success message
        } elseif (isset($_SESSION['error'])) {
            echo '<p class="error">' . $_SESSION['error'] . '</p>';
            unset($_SESSION['error']); // Clear error message
        }
        ?>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST" enctype="multipart/form-data">
            <label for="date">Date:</label>
            <input type="date" id="date" name="date" value="<?php echo $date; ?>" required><br><br>

            <label for="activities">Activities:</label><br>
            <textarea id="activities" name="activities" rows="4" cols="50" required><?php echo $activities; ?></textarea><br><br>

            <label for="accomplishments">Accomplishments:</label><br>
            <textarea id="accomplishments" name="accomplishments" rows="4" cols="50" required><?php echo $accomplishments; ?></textarea><br><br>

            <label for="challenges">Challenges Faced:</label><br>
            <textarea id="challenges" name="challenges" rows="4" cols="50" required><?php echo $challenges; ?></textarea><br><br>

            <label for="project_details">Project Details:</label><br>
            <input type="text" id="project_details" name="project_details" value="<?php echo $project_details; ?>" required><br><br>

            <label for="tasks_completed">Tasks Completed:</label><br>
            <input type="text" id="tasks_completed" name="tasks_completed" value="<?php echo $tasks_completed; ?>" required><br><br>

            <label for="hours_worked">Hours Worked:</label><br>
            <input type="number" id="hours_worked" name="hours_worked" value="<?php echo $hours_worked; ?>" required><br><br>

            <label for="attachments">Attachments:</label><br>
            <input type="file" id="attachments" name="attachments[]" multiple><br><br>

            <input type="submit" value="Submit">
        </form>
    </div>
</body>
</html>
