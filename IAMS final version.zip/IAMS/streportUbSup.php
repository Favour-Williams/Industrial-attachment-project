<?php
// Create connection
$conn = mysqli_connect('localhost', 'root', '', 'db_iams');

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT * FROM reports";
$result = $conn->query($sql);

$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Weekly Log Book</title>
    <style>
        table, tr, th, td{
            border: 1px solid rgb(255, 255, 255);
            border-collapse: collapse;
            color: white;
            font-weight: bold;
        }
        table{
            width: 90%;
            margin-left: auto;
            margin-right: auto;
            margin-top: 30px;
            background-color: rgba(255, 255, 255, 0.3); 
        }
        caption{
            margin-bottom: 20px;
            font-size: 28px;
            font-weight: bold;
            font-style: italic;
            letter-spacing: 10px;
        }
        .button{
            margin-left: auto;
            margin-right: auto;
        }
        tr{
            text-align: center;
        }
        td{
            padding: 12px 10px;
        
        }
        th{
            padding: 15px 13px;
            font-size: 20px;
            background-color: rgb(0, 0, 0);
        }
       
        table tr:hover{
            background-color: rgb(90, 103, 141);
            transition: 0.25s ease-in-out;
        }
        .bg {
            animation:slide 3s ease-in-out infinite alternate;
            background-image: linear-gradient(-60deg, rgb(109, 79, 25) 50%, rgb(21, 83, 99) 50%);
            bottom:0;
            left:-50%;
            opacity:.5;
            position:fixed;
            right:-50%;
            top:0;
            z-index:-1;
        }
        
        .bg2 {
            animation-direction:alternate-reverse;
            animation-duration:4s;
        }
        
        .bg3 {
            animation-duration:5s;
        }
        

        @keyframes slide {
            0% {
            transform:translateX(-25%);
            }
            100% {
            transform:translateX(25%);
            }
        }
        .button {
            padding: 6px 16px;

            background-color: #00549ebb;
            color: white;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }
        
        .button:hover {
        
            padding: 10px 18px;
            transition: 0.3s ease-in-out;
            background: #030033;

            border: 2px solid white;
            border-radius: 5px;
            box-shadow: 0 0 5px #030033,
                        0 0 25px #030033,
                        0 0 50px #030033,
                        0 0 100px #030033;
        }

        table tr:hover {
            background-color: #464A52;
            -webkit-box-shadow: 0 6px 6px -6px #0E1119;
            -moz-box-shadow: 0 6px 6px -6px #0E1119;
            box-shadow: 0 6px 6px -6px #0E1119;
        }

        table td:hover {
            background-color: #2d1883;
          
            font-weight: bold;
            
            box-shadow: #2d1883 -1px 1px, #2d1883 -2px 2px, #2d1883 -3px 3px, #2d1883 -4px 4px, #2d1883 -5px 5px, #2d1883 -6px 6px;
            transform: translate3d(6px, -6px, 0);
            
            transition-delay: 0s;
            transition-duration: 0.4s;
            transition-property: all;
            transition-timing-function: line;
        }
    </style>
</head>
<body>

    <div class="bg"></div>
    <div class="bg bg2"></div>
    <div class="bg bg3"></div>


    <table>
        <thead>
            <tr>
                <th>S/N</th>
                <th>Student ID</th>
                <th>File Name</th>
                <th>Download</th>
            </tr>
        </thead>
        <tbody>
<?php
$count = 1;
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
    
        // Check if the file exists
        if (file_exists($row['file']) && substr($row['userID'], 0, 1) === '2') {
            echo "<tr>";
            echo "<td>" . $count . "</td>";
            echo "<td>" . $row['userID'] . "</td>";
            echo "<td>" . $row['file'] . "</td>";
            echo '<td><a href="' . $row['file'] . '" class="button" download>Download</a></td>';
        } 
        
        echo "</tr>";
        $count++;
    }
} else {
    echo "<tr><td colspan='4'>No records found.</td></tr>";
}
?>

            
        </tbody>
    </table>
</body>
</html>
