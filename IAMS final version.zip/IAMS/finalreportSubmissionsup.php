<?php

session_start();
// Create connection
$conn = mysqli_connect('localhost', 'root', '', 'db_iams');

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if all required fields are set
    // Debug statement to check if the form is submitted


    if (isset($_POST["submit"])) {
        $studentID = $_SESSION['orgId']; // Retrieve studentID from session
        $targetDir = "uploads/";
        $targetFile = $targetDir . basename($_FILES["pdfFile"]["name"]);
        $fileType = strtolower(pathinfo($targetFile,PATHINFO_EXTENSION));
        $uploads_dir = $_SERVER['DOCUMENT_ROOT'] . '/filedocs'; // Update the path to include DOCUMENT_ROOT

        // Create the directory if it doesn't exist
        if (!file_exists($uploads_dir)) {
            mkdir($uploads_dir, 0777, true); // Create directory with full permissions
        }

        // Move the uploaded file to the destination directory
        
        if (move_uploaded_file($_FILES["pdfFile"]["tmp_name"], $targetFile)) {
            // Prepare SQL query for inserting Report entry
            $sql = "INSERT INTO reports (userID, file) VALUES ('$studentID', '$targetFile')";
            
            // Execute query
            if (mysqli_query($conn, $sql)) {
                echo "Report submission successful";
                header("refresh:3;url=supervisorProfile.php");
            } else {
                echo "Error: " . mysqli_error($conn);
            }
        } else {
            echo "Failed to move uploaded file.";
        }
    } else {
        echo "One or more required fields are missing.";
    }
}
?>
