<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registered Students</title>
    <link rel="stylesheet" href="matchStyle.css">
</head>
<body>
<header>
        <nav class="navigation">
    
            <a href="coordinator.php">Return to coordinator page</a>
            
        </nav>
    </header>
    <?php
        $conn = mysqli_connect('localhost', 'root', '', 'db_iams');

        // Check connection
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }
        
        function getStudentPreferences($conn) {
            $sql = "SELECT orgId, orgName FROM organisation";
            $stmt = $conn->prepare($sql);
            $stmt->execute();
            $result = $stmt->get_result();
            $studentInfo = $result->fetch_all(MYSQLI_ASSOC);
            return $studentInfo;
        }

        $studentInfo = getStudentPreferences($conn);
    ?>

    <div class='table-container'>
        <h1>Organisations</h1>
        <table class='rounded-table'>
        <tr>
            <th>orgID</th>
            <th>orgName</th>
        </tr>
        <?php foreach ($studentInfo as $student): ?>
            <tr>
                <td><?php echo htmlspecialchars($student['orgId']);?></td>
                <td><?php echo htmlspecialchars($student['orgName']);?></td>
            </tr>
        <?php endforeach; ?>
    </table>
    </div>
</body>
</html>
