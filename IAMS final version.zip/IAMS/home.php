<?php 
session_start();

include("homeget.php");

$errors = []; // Initialize an empty array to store errors

if($_SERVER['REQUEST_METHOD'] == 'POST')
{
    $email = $_POST['email'];
    $password = $_POST['password'];


    if(!empty($email) && !empty($password))
    {
        // Check in the student table
        $query_student = "SELECT * FROM student WHERE email = '$email' LIMIT 1";
        $result_student = mysqli_query($conn, $query_student);

        // Check in the staff table
        $query_coordinator = "SELECT * FROM coordinator WHERE coordinatorEmail = '$email' LIMIT 1";
        $result_coordinator = mysqli_query($conn, $query_coordinator);

        // Check in the ub_supervisor table
        $query_ubsupervisor = "SELECT * FROM coordinator WHERE coordinatorEmail = '$email' LIMIT 1";
        $result_ubsupervisor = mysqli_query($conn, $query_ubsupervisor);

        // Check in the supervisor table
        $query_supervisor = "SELECT * FROM ub_supervisor WHERE supervisorEmail = '$email' LIMIT 1";
        $result_supervisor = mysqli_query($conn, $query_supervisor);

        // Check in the supervisor table
        $query_orgsupervisor = "SELECT * FROM organisation WHERE supervisorEmail = '$email' LIMIT 1";
        $result_orgsupervisor = mysqli_query($conn, $query_orgsupervisor);

        if(mysqli_num_rows($result_student) > 0)
        {
            $user_data = mysqli_fetch_assoc($result_student);
            if(password_verify($password, $user_data['password']) )
            {
                $_SESSION['email'] = $email;
                $_SESSION['studentID'] = $user_data['studentID'];
                header("location: studentProfile.php");
                exit();
            }
        }
        elseif(mysqli_num_rows($result_coordinator) > 0) 
        {
            $coordinator_data = mysqli_fetch_assoc($result_coordinator);
            
            if(password_verify($password, $coordinator_data['coordinatorPassword']))
            {
                $_SESSION['coordinatorEmail'] = $email;
                header("location: coordinator.php");
                exit();
            }
        }

        elseif(mysqli_num_rows($result_supervisor) > 0) 
        {
            $supervisor_data = mysqli_fetch_assoc($result_supervisor);
            
            if(password_verify($password, $supervisor_data['supervisorPassword']))
            {
                $_SESSION['supervisorEmail'] = $email;
                header("location: UBsupervisor.php");
                exit();
            }
        }
        
        elseif(mysqli_num_rows($result_orgsupervisor) > 0)
        {
            $orgsupervisor_data = mysqli_fetch_assoc($result_orgsupervisor);
            if(password_verify($password, $orgsupervisor_data['password']))
            {
                $_SESSION['email'] = $email;
                $_SESSION['orgId'] = $orgsupervisor_data['orgId'];
                header("location: supervisorProfile.php");
                exit();
            }
        }
        $errors[] = "Incorrect email or password";
    }
    else{
        $errors[] = "Please enter both email and password";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="homeStyle.css">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
</head>
<body>
<header>
    <div class="logo"><img src="UBLogo.png" alt="ub"></div>
    <nav class="navigation">
        <a href="#">Home</a>
        <a href="#">About</a>
        <a href="#">Services</a>
        <a href="#">Contacts</a>
    </nav>
</header>
<div class="wrapper">
    <div class="form-box login">
        <h2>Login</h2>
        <!-- Display error messages -->
        <?php if (isset($errors) && count($errors) > 0): ?>
            <div class="error-messages">
                <?php foreach ($errors as $error): ?>
                    <p><?php echo htmlspecialchars($error); ?></p>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        <!-- End of error messages -->
        <form method="post">
            <div class="input-box">
                <span class="icon"><ion-icon name="mail"></ion-icon></span>
                <input type="email" name="email" required><label>Email</label>
            </div>
            <div class="input-box">
                <span class="icon"><ion-icon name="lock-closed"></ion-icon></span>
                <input type="password" name="password" required><label>Password</label>
            </div>
            <div class="forgot">
                <a href="#">Forgot Password?</a>
                <button type="submit" class="btn" name="login_user">Login</button>
            </div>
            <div class="login-register">
                <p>Don't have an account?<a href="#" class="register-link">Register</a></p>
            </div>
        </form>
    </div>

    <div class="form-box register">
        <h2>Registration</h2><br>
        <form action="#">
            <button type="submit" class="btn"><a href="register-attachment.html">Register for Attachment</a></button><br><br>
            <button type="submit" class="btn"><a href="register-organization.html">Register Organisation</a></button><br><br>
            <p>Already have an account?<a href="#" class="login-link">Login</a></p>
        </form>
    </div>
</div>
<script src="scriipt.js"></script>
<script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
</body>
</html>
