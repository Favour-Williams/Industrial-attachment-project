<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Registration Form</title>
  <link rel="stylesheet" href="register-attachmennt.css" />
  <script>
    function validateEmail() {
      var studentId = document.getElementById("studentid").value;
      var email = document.getElementById("email").value;
      var password = document.getElementById("password").value;
      var passwordRegex = /^(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+])[A-Za-z\d!@#$%^&*()_+]{8,}$/;
      // Extract first 9 numbers from student ID
      var idPrefix = studentId.substring(0, 9);
      
      // Expected email format
      var expectedEmail = idPrefix + "@ub.ac.bw";

      // Check if the entered email matches the expected format
      if (email !== expectedEmail) {
        alert("Email format is incorrect. It should start with the first 9 numbers of the student ID followed by '@ub.ac.bw'.");
        return false;
      }
      if (!password.match(passwordRegex)) {
          alert("Password must contain at least one capital letter, one number, one symbol, and be at least 8 characters long");
          return false;
      }
      return true;
    }
  </script>
</head>
<body>
  <div class="container">
    <div class="con">
      <img src="download (1).png" alt="ub logo">
    </div>
    <h1>Registration Form</h1>
    <p>Please fill out this form with the required information</p>
    <form method="post" action="connect.php" onsubmit="return validateEmail()">
      <fieldset>
        <label for="firstName">Enter Your First Name:</label>
        <input id="firstName" name="firstName" type="text" required>
      </fieldset>
      <fieldset>
        <label for="lastName">Enter Your Last Name:</label>
        <input id="lastName" name="lastName" type="text" required>
      </fieldset>
      <fieldset>
        <label for="email">Enter Your Student Email:</label>
        <input id="email" name="email" type="text" required>
      </fieldset>
      <fieldset>
        <label for="studentid">Enter Your Student ID:</label>
        <input id="studentid" name="studentid" type="text" required>
      </fieldset>
      <fieldset>
        <label for="password">Create a Password:</label>
        <input id="password" name="password" type="password" required>
      </fieldset>
      <fieldset>
        <label for="password">Confirm Password:</label>
        <input id="confirmpassword" name="confirmpassword" type="password" required>
        <?php echo $passworderror; ?>
      </fieldset>
      <label for="terms-and-conditions">
        <input class="inline" id="terms-and-conditions" type="checkbox" required name="terms-and-conditions"> I accept the <a href="https://www.freecodecamp.org/news/terms-of-service/">terms and conditions</a>
      </label>
      <input type="submit" name="record" value="Register">
    </form>
  </div>
</body>
</html>
