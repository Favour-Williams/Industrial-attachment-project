<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Matches</title>
    <link rel="stylesheet" href="matchStyle.css">
</head>
<body>

<?php
$conn = mysqli_connect('localhost', 'root', '', 'db_iams');

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Retrieve student ID from URL parameter
if (isset($_GET['student_id'])) {
    $student_id = $_GET['student_id'];

    // Fetch matches for the specified student ID
    $sql = "SELECT m.student_id, s.firstName AS student_name, m.organisation_id, o.orgName AS organisation_name 
            FROM matches AS m
            JOIN student AS s ON m.student_id = s.studentID
            JOIN organisation AS o ON m.organisation_id = o.orgId
            WHERE m.student_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $student_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $matches = $result->fetch_all(MYSQLI_ASSOC);
} else {
    // If no student ID is provided, display all matches
    $sql = "SELECT m.student_id, s.firstName AS student_name, m.organisation_id, o.orgName AS organisation_name 
            FROM matches AS m
            JOIN student AS s ON m.student_id = s.studentID
            JOIN organisation AS o ON m.organisation_id = o.orgId";
    $result = $conn->query($sql);
    $matches = $result->fetch_all(MYSQLI_ASSOC);
}
// Insert matches into the database without repeating rows
foreach ($matches as $match) {
    // Check if the match already exists
    $sql = "SELECT * FROM matches WHERE student_id = ? AND organisation_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $match['student_id'], $match['organisation_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows == 0) {
        // If not exists, insert the new match
        $sql = "INSERT INTO matches (student_id, organisation_id) VALUES (?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $match['student_id'], $match['organisation_id']);
        $stmt->execute();
    }
}
// Display matches with student first name and organisation name
echo "<div class='table-container'>";
echo "<h1>Matches</h1>";
echo "<table class='rounded-table'>";
echo "<tr><th>Student ID</th>
      <th>Student Name</th>
      <th>Organisation ID</th>
      <th>Organisation Name</th></tr>";
foreach ($matches as $row) {
    echo "<tr>";
    echo "<td style='padding: 8px;'>" . htmlspecialchars($row['student_id']) . "</td>";
    echo "<td style='padding: 8px;'>" . htmlspecialchars($row['student_name']) . "</td>";
    echo "<td style='padding: 8px;'>" . htmlspecialchars($row['organisation_id']) . "</td>";
    echo "<td style='padding: 8px;'>" . htmlspecialchars($row['organisation_name']) . "</td>";
    echo "</tr>";
}
echo "</table>";
echo "</div>";

mysqli_close($conn);
?>
</body>
</html>