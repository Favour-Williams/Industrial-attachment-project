<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Success</title>
    <style>
        body{
            background-color: lightblue;
        }

        .success-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 50vh; /* Adjust the height as desired */
            background-color: white;
            border-radius: 15px; /* Add rounded corners */
            padding: 20px; /* Add padding for spacing */
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5); /* Add shadow for depth */
            max-width: 50%; /* Limit the width */
            margin-left: 450px;
            margin-top: 250px;
        }

        .success-message {
            font-family: Arial, Helvetica, sans-serif;
            font-size: 40px;
            border: 1px solid #c3e6cb;
            color: #155724;
            padding: 20px;
            text-align: center;
            border-radius: 10px; /* Add rounded corners to the message */
        }
    </style>
</head>
<body>
    
</body>
</html>


<?php

$passworderror = $firstnameerror = $lastnameerror = "";

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Create connection
    $conn = mysqli_connect('localhost', 'root', '', 'db_iams');

    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Check if the student ID already exists
    $student_id = $_POST["studentid"];
    $sql_check_id = "SELECT * FROM student WHERE studentID = ?";
    $stmt_check_id = $conn->prepare($sql_check_id);
    $stmt_check_id->bind_param("s", $student_id);
    $stmt_check_id->execute();
    $result_check_id = $stmt_check_id->get_result();

    $password = $_POST["password"];
    $firstname = $_POST["firstName"];
    $lastname = $_POST["lastName"];
    $confirmPassword = $_POST["confirmpassword"];

    if ($password !== $confirmPassword) {
        // Passwords don't match
        $passworderror= "Passwords do not match. Please re-enter them.";
    }

    if (!preg_match("/^[a-zA-Z0-9\s]+$/", $firstname )) {
        $firstnameerror = "First name should only contain alphanumeric characters.";
    }

    if (!preg_match("/^[a-zA-Z0-9\s]+$/", $lastname)) {
        $lastnameerror = "Last name should only contain alphanumeric characters.";
    }

    // If the student ID already exists, set error message
    if ($result_check_id->num_rows > 0) {
        $studentIderror = "*Error: Student ID already exists. Please choose a different one.";
    } else {
        // Password encoding
        $password = $_POST['password'];
        $enc_password = password_hash($password, PASSWORD_DEFAULT);
        $role = 'student';

        // Prepare SQL query
        $sql = "INSERT INTO student (studentID, firstName, lastName, email, password, department) VALUES (?, ?, ?, ?, ?, ?)";

        // Prepare statement
        $stmt = $conn->prepare($sql);

        // Bind parameters
        $stmt->bind_param("ssssss", $_POST["studentid"], $_POST["firstName"], $_POST["lastName"], $_POST["email"],  $enc_password, $_POST["department"]);

        // Execute query
        if(empty($passworderror)){

        if ($stmt->execute()) {
            echo '<div class="success-container"><div class="success-message">Registration successful</div> </div>';

            header("refresh:1;url=home.php");
        } else {
            echo "Error: " . $stmt->error;
        }
    }
        // Close statement
        $stmt->close();
    }

    // Close connection
    $conn->close();
}

// If there's an error, include the HTML file for the form
if (!empty($passworderror) && !empty($firstnameerror) && !empty($lastnameerror)) {
    include 'register-attachment.html';
}
?>
