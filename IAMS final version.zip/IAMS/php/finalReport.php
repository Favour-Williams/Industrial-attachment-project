<?php

$conn = mysqli_connect('localhost', 'root', '', 'db_iams');
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}



// Process the form data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $studentName = $_POST['studentName'];
    $studentId = $_POST['studentId'];
    $programmeOfStudy = $_POST['programmeOfStudy'];
    $hostOrgName = $_POST['hostOrgName'];
    $departmentAttachedTo = $_POST['departmentAttachedTo'];
    $indSupervisorTitle = $_POST['indSupervisorTitle'];
    $indSupervisorPosition = $_POST['indSupervisorPosition'];
    $universityTutor = $_POST['universityTutor'];
    $attachmentDates = $_POST['attachmentDates'];
    $organizationOverview = $_POST['organizationOverview'];
    $itUsage = $_POST['itUsage'];
    $workDescription = $_POST['workDescription'];
    $skillsRequired = $_POST['skillsRequired'];
    $coursesPreparation = $_POST['coursesPreparation'];
    $learningSummary = $_POST['learningSummary'];
    $challengesFaced = $_POST['challengesFaced'];
    $contributionMade = $_POST['contributionMade'];
    $improvementSuggestions = $_POST['improvementSuggestions'];
    $careerInfluence = $_POST['careerInfluence'];

    // Prepare and bind the SQL statement
    $stmt = $conn->prepare("INSERT INTO reports (studentName, studentID, programmeOfStudy, hostOrgName, departmentAttachedTo, indSupervisorTitle, indSupervisorPosition, universityTutor, attachmentDates, organizationOverview, itUsage, workDescription, skillsRequired, coursesPreparation, learningSummary, challengesFaced, contributionMade, improvementSuggestions, careerInfluence) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssssssssssssssss", $studentName, $studentId, $programmeOfStudy, $hostOrgName, $departmentAttachedTo, $indSupervisorTitle, $indSupervisorPosition, $universityTutor, $attachmentDates, $organizationOverview, $itUsage, $workDescription, $skillsRequired, $coursesPreparation, $learningSummary, $challengesFaced, $contributionMade, $improvementSuggestions, $careerInfluence);

    // Execute the statement
    $stmt->execute();

    echo "New record inserted successfully";

    // Close the statement and connection
    $stmt->close();
    $conn->close();
}
?>
