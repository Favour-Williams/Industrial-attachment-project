<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Success</title>
    <style>
        body{
            background-color: lightblue;
        }

        .success-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 50vh; /* Adjust the height as desired */
            background-color: white;
            border-radius: 15px; /* Add rounded corners */
            padding: 20px; /* Add padding for spacing */
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5); /* Add shadow for depth */
            max-width: 50%; /* Limit the width */
            margin-left: 450px;
            margin-top: 250px;
        }

        .success-message {
            font-family: Arial, Helvetica, sans-serif;
            font-size: 40px;
            border: 1px solid #c3e6cb;
            color: #155724;
            padding: 20px;
            text-align: center;
            border-radius: 10px; /* Add rounded corners to the message */
        }
    </style>
</head>
<body>
    
</body>
</html>
<?php

$passworderror = $orgEmailerror = $supEmailerror = $phoneNumbererror = "";

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Create connection
    $conn = mysqli_connect('localhost', 'root', '', 'db_iams');

    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Check if the organization email already exists
    $org_email = $_POST["orgEmail"];
    $sql_check_org_email = "SELECT * FROM organisation WHERE orgEmail = ?";
    $stmt_check_org_email = $conn->prepare($sql_check_org_email);
    $stmt_check_org_email->bind_param("s", $org_email);
    $stmt_check_org_email->execute();
    $result_check_org_email = $stmt_check_org_email->get_result();

    // If the organization email already exists, set error message
    if ($result_check_org_email->num_rows > 0) {
        $orgEmailerror = "Error: Organization email already exists. Please choose a different one.";
    }

    // Check if the supervisor email already exists
    $sup_email = $_POST["supervisorEmail"];
    $password = $_POST["password"];
    $confirmPassword = $_POST["confirmpassword"];
    $sql_check_sup_email = "SELECT * FROM organisation WHERE supervisorEmail = ?";
    $stmt_check_sup_email = $conn->prepare($sql_check_sup_email);
    $stmt_check_sup_email->bind_param("s", $sup_email);
    $stmt_check_sup_email->execute();
    $result_check_sup_email = $stmt_check_sup_email->get_result();

    if ($password !== $confirmPassword) {
        // Passwords don't match
        $passworderror= "Passwords do not match. Please re-enter them.";
    }

    // If the supervisor email already exists, set error message
    if ($result_check_sup_email->num_rows > 0) {
        $supEmailerror = "Error: Supervisor email already exists. Please choose a different one.";
    }

    // Check if the phone number already exists
    $phone_number = $_POST["phoneNumber"];
    $sql_check_phone_number = "SELECT * FROM organisation WHERE phoneNumber = ?";
    $stmt_check_phone_number = $conn->prepare($sql_check_phone_number);
    $stmt_check_phone_number->bind_param("s", $phone_number);
    $stmt_check_phone_number->execute();
    $result_check_phone_number = $stmt_check_phone_number->get_result();

    // If the phone number already exists, set error message
    if ($result_check_phone_number->num_rows > 0) {
        $phoneNumbererror = "Error: Phone number already exists. Please choose a different one.";
    }

    // If there are no errors, proceed with registration
    if (empty($orgEmailerror) && empty($supEmailerror) && empty($phoneNumbererror) && empty($passworderror)) {
        // Password encoding
        $password = $_POST['password'];
        $enc_password = password_hash($password, PASSWORD_DEFAULT);

        // Prepare SQL query
        $sql = "INSERT INTO organisation (orgName, supervisorName, supervisorEmail, orgEmail, address, orgId, password, phoneNumber, location) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        // Prepare statement
        $stmt = $conn->prepare($sql);

        // Bind parameters
        $stmt->bind_param("sssssssss", $_POST["orgName"], $_POST["supervisorName"], $_POST["supervisorEmail"], $_POST["orgEmail"], $_POST["address"], $_POST["orgId"], $enc_password, $_POST["phoneNumber"], $_POST["location"]);

        // Execute query
        if ($stmt->execute()) {
            echo '<div class="success-container"><div class="success-message">Registration successful</div> </div>';

            header("refresh:1;url=home.php");
        } else {
            echo "Error: " . $stmt->error;
        }

        // Close statement
        $stmt->close();
    }

    // Close connection
    $conn->close();
}

// If there's an error, include the HTML file for the form
if (!empty($orgEmailerror) || !empty($supEmailerror) || !empty($phoneNumbererror) || !empty($passworderror)) {
    include 'register-organization.html';
}
?>
