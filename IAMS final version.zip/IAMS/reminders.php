<?php
// Set connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_iams";

// Create a PDO connection
$pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);

    $sql = "UPDATE user SET logbooks_due = 1";
    header("refresh:0;url=coordinator.php");
    $pdo->exec($sql);

?>
