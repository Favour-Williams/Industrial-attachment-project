<?php
// Create connection
$conn = mysqli_connect('localhost', 'root', '', 'db_iams');

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and validate input data
    $studentId = mysqli_real_escape_string($conn, $_POST['student_id']);
    $assessmentId = mysqli_real_escape_string($conn, $_POST['assessment_id']);
    $mark = mysqli_real_escape_string($conn, $_POST['marks'][0]); // Assuming only one mark is submitted

    // Prepare and execute SQL query to insert into assessment table
    $query = "INSERT INTO assessment (studentID, assessmentID, mark) VALUES (?, ?, ?)";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "sss", $studentId, $assessmentId, $mark);
    $result = mysqli_stmt_execute($stmt);

    // Check if the query executed successfully
    if ($result) {
        echo "Assessment marks inserted successfully!";
    } else {
        echo "Error inserting assessment marks: " . mysqli_error($conn);
    }

    // Close statement
    mysqli_stmt_close($stmt);
}

// Fetch student IDs from the student table
$sql = "SELECT studentID FROM student";
$result = mysqli_query($conn, $sql);

// Check if query was successful
if ($result) {
    // Initialize an empty array to store student IDs
    $studentIds = array();

    // Fetch associative array of student IDs
    while ($row = mysqli_fetch_assoc($result)) {
        // Append each student ID to the array
        $studentIds[] = $row['studentID'];
    }

    // Free result set
    mysqli_free_result($result);
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Input Assessment Results</title>
  <link rel="stylesheet" href="assessmentStyle.css">
</head>
<body>
<header>
        <nav class="navigation">
    
            <a href="UBsupervisor.php">Return to supervisor page</a>
            
        </nav>
    </header>
    <div class="con">
  <h1>Input Assessment Results</h1>
  <form method="post">
    <label for="user_id">Select Student:</label>
    <select name="user_id" id="user_id">
      <?php foreach ($studentIds as $studentId) : ?>
        <option value="<?php echo $studentId; ?>"><?php echo $studentId; ?></option>
      <?php endforeach; ?>
    </select>
    <br>
    <label for="assessment_id">Enter Assessment ID:</label>
    <input type="text" name="assessment_id" id="assessment_id" required>
    <br>
    <label for="mark">Enter Mark:</label>
    <input type="number" name="marks[]" id="mark" step="0.01" required>
    <br>
    <button type="submit">Submit</button>
  </form>
  </div>
</body>
</html>
