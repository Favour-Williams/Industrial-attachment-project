<?php
// Set connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_iams";

// Create a PDO connection
$pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);

    // If it's Sunday, set a flag in the database indicating that logbooks are due
    $sql = "UPDATE user SET logbooks_due = 0";
    header("refresh:0;url=coordinator.php");
    $pdo->exec($sql);

?>
