<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Success</title>
    <style>
        body{
            background-color: lightblue;
        }

        .success-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 50vh; /* Adjust the height as desired */
            background-color: white;
            border-radius: 15px; /* Add rounded corners */
            padding: 20px; /* Add padding for spacing */
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5); /* Add shadow for depth */
            max-width: 50%; /* Limit the width */
            margin-left: 450px;
            margin-top: 250px;
        }

        .success-message {
            font-family: Arial, Helvetica, sans-serif;
            font-size: 40px;
            border: 1px solid #c3e6cb;
            color: #155724;
            padding: 20px;
            text-align: center;
            border-radius: 10px; /* Add rounded corners to the message */
        }
    </style>
</head>
<body>
    
</body>
</html>
<?php
session_start();
// Create connection
$conn = mysqli_connect('localhost', 'root', '', 'db_iams');

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve orgId from form submission
    $orgId = $_SESSION['orgId'];
    $typeOfWork = $_POST["typeOfWork"];
    $noOfStudents = $_POST["noOfStudents"];

    // Prepare SQL query for updating organization preferences
    $sql = "UPDATE organisation SET typeOfWork = ?, noOfStudents = ? WHERE orgId = ?";

    // Prepare statement
    $stmt = $conn->prepare($sql);

    // Bind parameters
    $stmt->bind_param("sii", $typeOfWork, $noOfStudents, $orgId);

    // Execute query
    if ($stmt->execute()) {
        echo '<div class="success-container"><div class="success-message">Preferences saved successfully</div> </div>';

        // Prepare SQL query to find matches
        $sql_match = "INSERT INTO matches (student_id, organisation_id) 
                      SELECT studentID, ? FROM student
                      WHERE location = (SELECT location FROM organisation WHERE orgId = ?) AND typeOfWork = ?"; 

        // Prepare statement for finding matches
        $stmt_match = $conn->prepare($sql_match);

        // Bind parameters for finding matches
        $stmt_match->bind_param("iis", $orgId, $orgId, $typeOfWork);
        
         // Execute query to find matches
         if ($stmt_match->execute()) {
            echo " ";
        } else {
            echo "Error inserting matches: " . $stmt_match->error;
            exit(); // Exit if error occurs
        }

        // Close matches statement
        $stmt_match->close();

        // Redirect to supervisor profile page after 3 seconds
        header("refresh:1;url=supervisorProfile.php");
        exit(); 
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close statement
    $stmt->close();
}

// Close connection
$conn->close();

?>
