let weeklyEntryCount = 1;

function addWeeklyEntry() {

   
  const weeklyEntriesDiv = document.getElementById('weeklyEntries');

  const entryDiv = document.createElement('div');
  entryDiv.classList.add('weekly-entry');

  entryDiv.innerHTML = `
    <h3>Weekly Entry ${weeklyEntryCount}</h3>
    <label for="workDescription${weeklyEntryCount}">General Description of Work:</label><br>
    <textarea id="workDescription${weeklyEntryCount}" required></textarea><br>

    <label for="technicalDescription${weeklyEntryCount}">Technical Description:</label><br>
    <textarea id="technicalDescription${weeklyEntryCount}" required></textarea><br>

    <label for="exampleMaterial${weeklyEntryCount}">Example Material:</label><br>
    <textarea id="exampleMaterial${weeklyEntryCount}" required></textarea><br>

    <label for="summary${weeklyEntryCount}">Summary of Achievements:</label><br>
    <textarea id="summary${weeklyEntryCount}" required></textarea><br>

    <label for="reflection${weeklyEntryCount}">Reflection:</label><br>
    <textarea id="reflection${weeklyEntryCount}" required></textarea><br>

    <label for="objectives${weeklyEntryCount}">Objectives for Next Week:</label><br>
    <textarea id="objectives${weeklyEntryCount}" required></textarea><br>

    <label for="indSupervisorComments${weeklyEntryCount}">Industrial Supervisor's Comments:</label><br>
    <textarea id="indSupervisorComments${weeklyEntryCount}" required></textarea><br>

    <label for="uniTutorComments${weeklyEntryCount}">University Tutor's Comments:</label><br>
    <textarea id="uniTutorComments${weeklyEntryCount}" required></textarea><br>
  `;

  weeklyEntriesDiv.appendChild(entryDiv);
  weeklyEntryCount++;

  document.getElementById('addWeeklyEntryBtn').disabled = true;

  // Enable the button after a week has passed
  setTimeout(() => {
    document.getElementById('addWeeklyEntryBtn').disabled = false;
  }, 7 * 24 * 60 * 60 * 1000); // 7 days in milliseconds
}

