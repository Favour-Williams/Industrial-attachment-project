const info = document.getElementById('info');
    const num = document.getElementById('num');

    function nextSection(currentSectionId, nextSectionId) {
      const currentSection = document.getElementById(currentSectionId);
      const nextSection = document.getElementById(nextSectionId);

      if (currentSection && nextSection) {
        currentSection.classList.add('fade-out');
        currentSection.classList.remove('fade-in');
        setTimeout(() => {
          currentSection.style.display = 'none';
          nextSection.style.display = 'block';
          nextSection.classList.remove('hide-section');
          nextSection.classList.add('fade-in');
        }, 500);
      }
    }

    function prevSection(currentSectionId, prevSectionId) {
      const currentSection = document.getElementById(currentSectionId);
      const prevSection = document.getElementById(prevSectionId);

      if (currentSection && prevSection) {
        currentSection.classList.add('fade-out');
        currentSection.classList.remove('fade-in');
        setTimeout(() => {
          currentSection.style.display = 'none';
          prevSection.style.display = 'block';
          prevSection.classList.remove('hide-section');
          prevSection.classList.add('fade-in');
        }, 500);
      }
    }

    // Add event listeners to your buttons
    document.querySelectorAll('button[data-action="next"]').forEach(button => {
      button.addEventListener('click', function() {
        const currentSectionId = this.getAttribute('data-current');
        const nextSectionId = this.getAttribute('data-next');
        nextSection(currentSectionId, nextSectionId);
      });
    });

    document.querySelectorAll('button[data-action="prev"]').forEach(button => {
      button.addEventListener('click', function() {
        const currentSectionId = this.getAttribute('data-current');
        const prevSectionId = this.getAttribute('data-prev');
        prevSection(currentSectionId, prevSectionId);
      });
    });