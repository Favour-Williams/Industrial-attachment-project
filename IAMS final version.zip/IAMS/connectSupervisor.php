<?php
// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Create connection
    $conn = mysqli_connect('localhost', 'root', '', 'db_iams');

    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Prepare SQL query
    $sql = "INSERT INTO reports (studentID, orgID, attendance, communicationSkills, technicalSkills, problemSolvingSkills, contribution, professionalism, grade, comments) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    // Prepare statement
    $stmt = $conn->prepare($sql);

    // Bind parameters
    $stmt->bind_param("sissssssss",  $_POST["studentID"], $_POST["orgID"], $_POST["attendance"], $_POST["communicationSkills"], $_POST["technicalSkills"], $_POST["problemSolvingSkills"], $_POST["contribution"], $_POST["professionalism"], $_POST["grade"], $_POST["comments"]);

    // Execute query
    if ($stmt->execute()) {
        echo "Registration successful";
        header("refresh:1;url=supervisorProfile.php");
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close statement
    $stmt->close();

    // Close connection
    $conn->close();
}
?>